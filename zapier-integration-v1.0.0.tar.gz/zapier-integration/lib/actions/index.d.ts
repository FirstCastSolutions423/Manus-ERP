declare const _default: ({
    key: string;
    noun: string;
    display: {
        label: string;
        description: string;
    };
    operation: {
        perform: (z: any, bundle: import("../types").ZapierBundle) => Promise<import("../types").Task>;
        inputFields: {
            key: string;
            label: string;
            required: boolean;
        }[];
        sample: {
            id: number;
            createdAt: string;
            updatedAt: string;
        };
    };
} | {
    key: string;
    noun: string;
    display: {
        label: string;
        description: string;
    };
    operation: {
        perform: (z: any, bundle: import("../types").ZapierBundle) => Promise<import("../types").Transaction>;
        inputFields: {
            key: string;
            label: string;
            required: boolean;
        }[];
        sample: {
            id: number;
            createdAt: string;
            updatedAt: string;
        };
    };
} | {
    key: string;
    noun: string;
    display: {
        label: string;
        description: string;
    };
    operation: {
        perform: (z: any, bundle: import("../types").ZapierBundle) => Promise<import("../types").Ticket>;
        inputFields: {
            key: string;
            label: string;
            required: boolean;
        }[];
        sample: {
            id: number;
            createdAt: string;
            updatedAt: string;
        };
    };
} | {
    key: string;
    noun: string;
    display: {
        label: string;
        description: string;
    };
    operation: {
        perform: (z: any, bundle: import("../types").ZapierBundle) => Promise<import("../types").Lead>;
        inputFields: {
            key: string;
            label: string;
            required: boolean;
        }[];
        sample: {
            id: number;
            createdAt: string;
            updatedAt: string;
        };
    };
} | {
    key: string;
    noun: string;
    display: {
        label: string;
        description: string;
    };
    operation: {
        perform: (z: any, bundle: import("../types").ZapierBundle) => Promise<import("../types").Contact>;
        inputFields: {
            key: string;
            label: string;
            required: boolean;
        }[];
        sample: {
            id: number;
            createdAt: string;
            updatedAt: string;
        };
    };
} | {
    key: string;
    noun: string;
    display: {
        label: string;
        description: string;
    };
    operation: {
        perform: (z: any, bundle: import("../types").ZapierBundle) => Promise<import("../types").Employee>;
        inputFields: {
            key: string;
            label: string;
            required: boolean;
        }[];
        sample: {
            id: number;
            createdAt: string;
            updatedAt: string;
        };
    };
} | {
    key: string;
    noun: string;
    display: {
        label: string;
        description: string;
    };
    operation: {
        perform: (z: any, bundle: import("../types").ZapierBundle) => Promise<import("../types").PurchaseOrder>;
        inputFields: {
            key: string;
            label: string;
            required: boolean;
        }[];
        sample: {
            id: number;
            createdAt: string;
            updatedAt: string;
        };
    };
})[];
export default _default;
//# sourceMappingURL=index.d.ts.map