import { ZapierBundle, Task } from '../types';
declare const _default: {
    key: string;
    noun: string;
    display: {
        label: string;
        description: string;
    };
    operation: {
        perform: (z: any, bundle: ZapierBundle) => Promise<Task>;
        inputFields: {
            key: string;
            label: string;
            required: boolean;
        }[];
        sample: {
            id: number;
            createdAt: string;
            updatedAt: string;
        };
    };
};
export default _default;
//# sourceMappingURL=createTask.d.ts.map