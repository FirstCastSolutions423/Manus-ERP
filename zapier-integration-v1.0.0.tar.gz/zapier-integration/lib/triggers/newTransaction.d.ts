import { ZapierBundle, Transaction } from '../types';
declare const _default: {
    key: string;
    noun: string;
    display: {
        label: string;
        description: string;
        important: boolean;
    };
    operation: {
        type: string;
        performSubscribe: (z: any, bundle: ZapierBundle) => Promise<any>;
        performUnsubscribe: (z: any, bundle: ZapierBundle) => Promise<{}>;
        perform: (z: any, bundle: ZapierBundle) => Promise<Transaction[]>;
        performList: (z: any, bundle: ZapierBundle) => Promise<Transaction[]>;
        inputFields: never[];
        outputFields: {
            key: string;
            label: string;
            type: string;
        }[];
        sample: {
            id: number;
            type: string;
            amount: number;
            description: string;
            date: string;
            createdAt: string;
        };
    };
};
export default _default;
//# sourceMappingURL=newTransaction.d.ts.map