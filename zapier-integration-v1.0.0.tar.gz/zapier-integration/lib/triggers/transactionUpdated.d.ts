import { ZapierBundle, Transaction } from '../types';
declare const _default: {
    key: string;
    noun: string;
    display: {
        label: string;
        description: string;
    };
    operation: {
        type: string;
        performSubscribe: (z: any, bundle: ZapierBundle) => Promise<any>;
        performUnsubscribe: (z: any, bundle: ZapierBundle) => Promise<{}>;
        perform: (z: any, bundle: ZapierBundle) => Promise<Transaction[]>;
        performList: (z: any, bundle: ZapierBundle) => Promise<Transaction[]>;
        inputFields: never[];
        outputFields: {
            key: string;
            label: string;
            type: string;
        }[];
        sample: {
            id: number;
            type: string;
            amount: number;
            flagged: boolean;
            updatedAt: string;
        };
    };
};
export default _default;
//# sourceMappingURL=transactionUpdated.d.ts.map