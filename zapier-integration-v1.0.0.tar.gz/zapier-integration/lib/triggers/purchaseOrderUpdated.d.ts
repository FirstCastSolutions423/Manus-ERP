import { ZapierBundle, PurchaseOrder } from '../types';
declare const _default: {
    key: string;
    noun: string;
    display: {
        label: string;
        description: string;
    };
    operation: {
        type: string;
        performSubscribe: (z: any, bundle: ZapierBundle) => Promise<any>;
        performUnsubscribe: (z: any, bundle: ZapierBundle) => Promise<{}>;
        perform: (z: any, bundle: ZapierBundle) => Promise<PurchaseOrder[]>;
        performList: (z: any, bundle: ZapierBundle) => Promise<PurchaseOrder[]>;
        inputFields: never[];
        outputFields: {
            key: string;
            label: string;
            type: string;
        }[];
        sample: {
            id: number;
            createdAt: string;
            updatedAt: string;
        };
    };
};
export default _default;
//# sourceMappingURL=purchaseOrderUpdated.d.ts.map