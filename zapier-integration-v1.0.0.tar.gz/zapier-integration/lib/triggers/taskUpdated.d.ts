import { ZapierBundle, Task } from '../types';
declare const _default: {
    key: string;
    noun: string;
    display: {
        label: string;
        description: string;
    };
    operation: {
        type: string;
        performSubscribe: (z: any, bundle: ZapierBundle) => Promise<any>;
        performUnsubscribe: (z: any, bundle: ZapierBundle) => Promise<{}>;
        perform: (z: any, bundle: ZapierBundle) => Promise<Task[]>;
        performList: (z: any, bundle: ZapierBundle) => Promise<Task[]>;
        inputFields: never[];
        outputFields: {
            key: string;
            label: string;
            type: string;
        }[];
        sample: {
            id: number;
            title: string;
            status: string;
            priority: string;
            updatedAt: string;
        };
    };
};
export default _default;
//# sourceMappingURL=taskUpdated.d.ts.map