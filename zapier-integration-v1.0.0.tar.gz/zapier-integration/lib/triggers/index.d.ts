declare const _default: ({
    key: string;
    noun: string;
    display: {
        label: string;
        description: string;
    };
    operation: {
        type: string;
        performSubscribe: (z: any, bundle: import("../types").ZapierBundle) => Promise<any>;
        performUnsubscribe: (z: any, bundle: import("../types").ZapierBundle) => Promise<{}>;
        perform: (z: any, bundle: import("../types").ZapierBundle) => Promise<import("../types").Task[]>;
        performList: (z: any, bundle: import("../types").ZapierBundle) => Promise<import("../types").Task[]>;
        inputFields: never[];
        outputFields: {
            key: string;
            label: string;
            type: string;
        }[];
        sample: {
            id: number;
            title: string;
            status: string;
            priority: string;
            updatedAt: string;
        };
    };
} | {
    key: string;
    noun: string;
    display: {
        label: string;
        description: string;
        important: boolean;
    };
    operation: {
        type: string;
        performSubscribe: (z: any, bundle: import("../types").ZapierBundle) => Promise<any>;
        performUnsubscribe: (z: any, bundle: import("../types").ZapierBundle) => Promise<{}>;
        perform: (z: any, bundle: import("../types").ZapierBundle) => Promise<import("../types").Transaction[]>;
        performList: (z: any, bundle: import("../types").ZapierBundle) => Promise<import("../types").Transaction[]>;
        inputFields: never[];
        outputFields: {
            key: string;
            label: string;
            type: string;
        }[];
        sample: {
            id: number;
            type: string;
            amount: number;
            description: string;
            date: string;
            createdAt: string;
        };
    };
} | {
    key: string;
    noun: string;
    display: {
        label: string;
        description: string;
    };
    operation: {
        type: string;
        performSubscribe: (z: any, bundle: import("../types").ZapierBundle) => Promise<any>;
        performUnsubscribe: (z: any, bundle: import("../types").ZapierBundle) => Promise<{}>;
        perform: (z: any, bundle: import("../types").ZapierBundle) => Promise<import("../types").Transaction[]>;
        performList: (z: any, bundle: import("../types").ZapierBundle) => Promise<import("../types").Transaction[]>;
        inputFields: never[];
        outputFields: {
            key: string;
            label: string;
            type: string;
        }[];
        sample: {
            id: number;
            type: string;
            amount: number;
            flagged: boolean;
            updatedAt: string;
        };
    };
} | {
    key: string;
    noun: string;
    display: {
        label: string;
        description: string;
    };
    operation: {
        type: string;
        performSubscribe: (z: any, bundle: import("../types").ZapierBundle) => Promise<any>;
        performUnsubscribe: (z: any, bundle: import("../types").ZapierBundle) => Promise<{}>;
        perform: (z: any, bundle: import("../types").ZapierBundle) => Promise<import("../types").Ticket[]>;
        performList: (z: any, bundle: import("../types").ZapierBundle) => Promise<import("../types").Ticket[]>;
        inputFields: never[];
        outputFields: {
            key: string;
            label: string;
            type: string;
        }[];
        sample: {
            id: number;
            createdAt: string;
            updatedAt: string;
        };
    };
} | {
    key: string;
    noun: string;
    display: {
        label: string;
        description: string;
    };
    operation: {
        type: string;
        performSubscribe: (z: any, bundle: import("../types").ZapierBundle) => Promise<any>;
        performUnsubscribe: (z: any, bundle: import("../types").ZapierBundle) => Promise<{}>;
        perform: (z: any, bundle: import("../types").ZapierBundle) => Promise<import("../types").Lead[]>;
        performList: (z: any, bundle: import("../types").ZapierBundle) => Promise<import("../types").Lead[]>;
        inputFields: never[];
        outputFields: {
            key: string;
            label: string;
            type: string;
        }[];
        sample: {
            id: number;
            createdAt: string;
            updatedAt: string;
        };
    };
} | {
    key: string;
    noun: string;
    display: {
        label: string;
        description: string;
    };
    operation: {
        type: string;
        performSubscribe: (z: any, bundle: import("../types").ZapierBundle) => Promise<any>;
        performUnsubscribe: (z: any, bundle: import("../types").ZapierBundle) => Promise<{}>;
        perform: (z: any, bundle: import("../types").ZapierBundle) => Promise<import("../types").Employee[]>;
        performList: (z: any, bundle: import("../types").ZapierBundle) => Promise<import("../types").Employee[]>;
        inputFields: never[];
        outputFields: {
            key: string;
            label: string;
            type: string;
        }[];
        sample: {
            id: number;
            createdAt: string;
            updatedAt: string;
        };
    };
} | {
    key: string;
    noun: string;
    display: {
        label: string;
        description: string;
    };
    operation: {
        type: string;
        performSubscribe: (z: any, bundle: import("../types").ZapierBundle) => Promise<any>;
        performUnsubscribe: (z: any, bundle: import("../types").ZapierBundle) => Promise<{}>;
        perform: (z: any, bundle: import("../types").ZapierBundle) => Promise<import("../types").PurchaseOrder[]>;
        performList: (z: any, bundle: import("../types").ZapierBundle) => Promise<import("../types").PurchaseOrder[]>;
        inputFields: never[];
        outputFields: {
            key: string;
            label: string;
            type: string;
        }[];
        sample: {
            id: number;
            createdAt: string;
            updatedAt: string;
        };
    };
})[];
export default _default;
//# sourceMappingURL=index.d.ts.map