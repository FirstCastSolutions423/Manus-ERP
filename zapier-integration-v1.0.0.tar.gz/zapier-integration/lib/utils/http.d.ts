import { ZapierBundle } from '../types';
export interface RequestOptions {
    method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
    url: string;
    params?: Record<string, any>;
    body?: Record<string, any>;
    headers?: Record<string, string>;
}
export declare const makeRequest: (z: any, options: RequestOptions) => Promise<any>;
export declare const makeAuthenticatedRequest: (z: any, bundle: ZapierBundle, options: Omit<RequestOptions, "headers"> & {
    headers?: Record<string, string>;
}) => Promise<any>;
export declare const handleErrors: (response: any, z: any) => any;
export declare const generateIdempotencyKey: () => string;
export declare const verifyWebhookSignature: (payload: string, signature: string, secret: string) => boolean;
export declare const dedupeKey: (obj: any) => string;
//# sourceMappingURL=http.d.ts.map