declare const App: {
    version: any;
    platformVersion: string;
    authentication: {
        type: string;
        oauth2Config: {
            authorizeUrl: {
                url: string;
                params: {
                    client_id: string;
                    response_type: string;
                    redirect_uri: string;
                    scope: string;
                    state: string;
                    code_challenge: string;
                    code_challenge_method: string;
                };
            };
            getAccessToken: (z: any, bundle: any) => Promise<{
                access_token: any;
                refresh_token: any;
                expires_in: any;
                token_type: any;
            }>;
            refreshAccessToken: (z: any, bundle: any) => Promise<{
                access_token: any;
                refresh_token: any;
                expires_in: any;
            }>;
            autoRefresh: boolean;
            scope: string;
        };
        test: (z: any, bundle: any) => Promise<any>;
        connectionLabel: (z: any, bundle: any) => string;
        fields: {
            key: string;
            type: string;
            required: boolean;
            computed: boolean;
            label: string;
        }[];
    };
    beforeRequest: ((request: any, z: any, bundle: any) => any)[];
    afterResponse: ((response: any, z: any, bundle: any) => any)[];
    triggers: any;
    searches: any;
    creates: any;
    resources: {};
};
export default App;
//# sourceMappingURL=index.d.ts.map