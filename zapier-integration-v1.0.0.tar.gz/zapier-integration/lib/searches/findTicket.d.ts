import { ZapierBundle, Ticket } from '../types';
declare const _default: {
    key: string;
    noun: string;
    display: {
        label: string;
        description: string;
    };
    operation: {
        perform: (z: any, bundle: ZapierBundle) => Promise<Ticket[]>;
        inputFields: {
            key: string;
            label: string;
            required: boolean;
        }[];
        sample: {
            id: number;
            createdAt: string;
        };
    };
};
export default _default;
//# sourceMappingURL=findTicket.d.ts.map